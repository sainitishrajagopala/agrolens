# AgroLens

A browser-based agricultural research assistant for exploring crop prices and yields, with traceable calculations and source rows.

## Features

- Upload CSV files (up to 5 MB and 30,000 rows).
- Filter by crop, region, and year; switch between prices and yields.
- Ask supported questions about averages, extrema, group comparisons, and changes over time.
- Inspect yearly charts, calculation formulas, and the CSV line numbers behind results.
- Process files in browser memory; no backend, API key, installation, or build step is required.

## Run locally

Download or clone this repository, then open `index.html` in a modern browser. Keep `index.html`, `style.css`, and `app.js` in the same folder.

Optionally serve the folder with Python:

```sh
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Try these questions

- What is the average corn price?
- Which crop has the highest yield?
- Compare yields by crop
- What is the highest price?
- How did corn prices change over time?

Questions use the active filters. Crop, region, and year mentions further narrow those filters. If a question has no supported calculation pattern, the app asks you to rephrase it.

## CSV format

Required columns: `year`, `crop`, `region`, plus at least one of `price` or `yield`.

Recommended columns: `price_unit`, `yield_unit`, and `source`.

```csv
year,crop,region,price,price_unit,yield,yield_unit,source
2024,Corn,Iowa,4.10,USD/bushel,209,bushels/acre,Illustrative sample - not official data
```

Column names are case-insensitive. Years must be integers from 1800 to 2200. Prices and yields must be nonnegative numbers; leave missing values blank. Quote fields containing commas. Numbers must use a decimal point without currency symbols or thousands separators.

`sample_data.csv` contains the same illustrative data bundled with the app. **All sample values are invented for demonstration and must not be cited as official statistics.**

## Calculation rules

- Means are unweighted row averages, not production-weighted or acreage-weighted estimates.
- Missing values are excluded, rather than counted as zero.
- Different unit labels are never combined. Units are not automatically converted.
- When units are missing, calculations spanning multiple crops are blocked.
- Trends compare the means of the earliest and latest matching years. Percentage change is undefined when the starting mean is zero.
- A question asking which crop has the highest yield compares crop means. A question asking for the highest yield without specifying a grouping returns the highest individual observation.
- Source rows include CSV line numbers. The table displays up to 100 contributing rows; calculations use all matching rows.
- Yield comparisons across crops in bushels do not compare mass, nutritional value, or profitability.

## Technology and structure

| File | Responsibility |
| --- | --- |
| `index.html` | Accessible page structure and controls |
| `style.css` | Responsive layout and styling |
| `app.js` | CSV validation, filters, question patterns, calculations, SVG charts, and evidence |
| `sample_data.csv` | Illustrative sample and upload template |
| `.gitignore` | Excludes common local files and secrets |

The app uses plain HTML, CSS, and JavaScript with no third-party runtime dependencies. Where supported, it also registers an optional browser WebMCP tool for asking dataset questions.

## Privacy and limitations

Uploaded data stays in the current page's memory and is cleared when the page is refreshed or closed. Source labels come from the uploaded CSV and are not independently verified.

This version uses rule-based question matching and deterministic calculations. **It does not call Claude or another language model.** It does not fetch live market data, explain causal drivers, produce forecasts, or support unrestricted natural-language questions. Irregular phrasing may need to be rewritten into one of the supported examples.

Calculation and parsing checks covered sample results, missing values, invalid numeric values, quoted fields, incompatible units, and empty filters. Full visual browser testing and validation in a supported WebMCP browser were not performed.

## Save this project to GitHub

1. Extract the ZIP on your computer.
2. Create a repository named `agrolens` at GitHub. Choose Public for a portfolio or Private for personal work. For a new repository, leave the initialization checkboxes off because this package already includes a README.
3. On the empty repository page, choose **uploading an existing file**. If your repository already contains files, use **Add file → Upload files**.
4. Upload the files inside the extracted `agrolens` folder. Keep `index.html` at the repository root. Upload the extracted files, not the ZIP itself.
5. Enter a commit message such as `Add initial AgroLens project` and commit the changes.

Suggested repository description: `Agricultural price and yield analysis with CSV uploads, charts, rule-based questions, and traceable source evidence.`

The existing hosted app remains separate from your GitHub repository. Uploading these files does not automatically synchronize later GitHub changes with that app. Its current deployment is private, so it is not yet a public recruiter demo.

## Possible next steps

- Connect the Claude API through a server endpoint to interpret broader questions while keeping calculations deterministic.
- Add real agricultural datasets with documented provenance.
- Add automated browser tests and a public demo when ready.

Never commit API keys or confidential datasets. Future AI integration would require explicit handling of what data is sent to the model provider.
